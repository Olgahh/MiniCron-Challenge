## cron parser challenge
_____


#### Run the following command:

```angular2html
cat config.txt | python main.py 16:10
```

#### This script will tell you when the next cronjob will be done based on the time you are passing

